import cv2
import mediapipe as mp
import numpy as np
from tensorflow.keras.models import load_model
import os
import collections # For deque

# --- Configuration ---
MODELS_PATH = os.path.join('models')
MODEL_FILENAME = 'sign_language_model.h5'
MODEL_PATH = os.path.join(MODELS_PATH, MODEL_FILENAME)

# Load signs from signs.txt, or use default if not found
try:
    with open('signs.txt', 'r') as f:
        SIGNS = [line.strip() for line in f if line.strip()]
except FileNotFoundError:
    print("Warning: 'signs.txt' not found. Using default signs for detection: ['hi', 'go'].")
    SIGNS = ['hi', 'go']

SEQUENCE_LENGTH = 30 # Must match the SEQUENCE_LENGTH used in collect_data.py and train_model.py
THRESHOLD = 0.8 # Minimum prediction probability to display a sign

# --- MediaPipe Setup ---
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(min_detection_confidence=0.7, min_tracking_confidence=0.7)
mp_drawing = mp.solutions.drawing_utils

# --- Load Model ---
try:
    model = load_model(MODEL_PATH)
    print(f"Successfully loaded model from {MODEL_PATH}")
except Exception as e:
    print(f"Error: Could not load model from {MODEL_PATH}. Please ensure it's trained and saved.")
    print(f"Error details: {e}")
    exit() # Exit if model cannot be loaded

# --- Helper Function to Extract Landmarks ---
def extract_landmarks(results):
    """
    Extracts hand landmark coordinates from MediaPipe results.
    Returns a flattened numpy array of (x, y, z) coordinates for all 21 landmarks.
    If no hand is detected, returns a zero array of the same shape.
    """
    if results.multi_hand_landmarks:
        # Assuming only one hand for simplicity.
        hand_landmarks = results.multi_hand_landmarks[0]
        keypoints = np.array([[lmk.x, lmk.y, lmk.z] for lmk in hand_landmarks.landmark]).flatten()
    else:
        keypoints = np.zeros(21 * 3) # 21 landmarks * 3 coordinates (x,y,z)
    return keypoints

# --- Main Real-time Detection Loop ---
def realtime_detection():
    cap = cv2.VideoCapture(0) # Open default webcam

    if not cap.isOpened():
        print("Error: Could not open webcam.")
        return

    # Deque to store the last SEQUENCE_LENGTH frames of landmark data
    # This acts as a rolling window for sequence prediction
    sequence = collections.deque(maxlen=SEQUENCE_LENGTH)
    predicted_sign = "None"
    prediction_probability = 0.0

    print("Starting real-time sign language detection. Press 'q' to quit.")

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret: break

        frame = cv2.flip(frame, 1) # Flip frame horizontally for mirror effect

        # Convert BGR to RGB
        image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        image_rgb.flags.writeable = False

        # Process with MediaPipe Hands
        results = hands.process(image_rgb)

        image_rgb.flags.writeable = True
        image_bgr = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR)

        # Draw hand landmarks
        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                mp_drawing.draw_landmarks(image_bgr, hand_landmarks, mp_hands.HAND_CONNECTIONS)

        # Extract landmarks and add to the sequence deque
        keypoints = extract_landmarks(results)
        sequence.append(keypoints)

        # Only make a prediction if we have enough frames in the sequence
        if len(sequence) == SEQUENCE_LENGTH:
            # Reshape the sequence for model input: (1, SEQUENCE_LENGTH, NUM_FEATURES)
            input_sequence = np.expand_dims(np.array(sequence), axis=0)
            
            # Make prediction
            predictions = model.predict(input_sequence, verbose=0)[0] # Get probabilities for all signs
            
            # Get the index of the highest probability
            predicted_idx = np.argmax(predictions)
            prediction_probability = predictions[predicted_idx]

            if prediction_probability > THRESHOLD:
                predicted_sign = SIGNS[predicted_idx]
            else:
                predicted_sign = "None" # Below threshold, consider it no sign or unknown

        # Display the predicted sign and probability
        cv2.putText(image_bgr, f'Sign: {predicted_sign}', (50, 50),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2, cv2.LINE_AA)
        cv2.putText(image_bgr, f'Prob: {prediction_probability:.2f}', (50, 100),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2, cv2.LINE_AA)

        cv2.imshow('Real-time Sign Language Detector', image_bgr)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    realtime_detection()
