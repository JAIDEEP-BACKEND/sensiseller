import numpy as np
import os
from sklearn.model_selection import train_test_split
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import TensorBoard, EarlyStopping, ReduceLROnPlateau
import matplotlib.pyplot as plt # For plotting training history

# --- Configuration ---
DATA_PATH = os.path.join('data') # Path to your collected data
MODELS_PATH = os.path.join('models') # Path to save your trained model

# Load signs from signs.txt, or use default if not found
try:
    with open('signs.txt', 'r') as f:
        SIGNS = [line.strip() for line in f if line.strip()]
except FileNotFoundError:
    print("Warning: 'signs.txt' not found. Using default signs for training: ['hi', 'go'].")
    SIGNS = ['hi', 'go']

SEQUENCE_LENGTH = 30 # Must match the SEQUENCE_LENGTH used in collect_data.py
NUM_FEATURES = 21 * 3 # 21 landmarks * 3 coordinates (x,y,z)

# --- Create Models Directory ---
if not os.path.exists(MODELS_PATH):
    os.makedirs(MODELS_PATH)

# --- Load Data ---
def load_data():
    """
    Loads all collected .npy files and prepares them for model training.
    Returns features (X) and labels (y).
    """
    sequences = []
    labels = []
    label_map = {sign: idx for idx, sign in enumerate(SIGNS)}

    print("Loading data...")
    for sign_idx, sign in enumerate(SIGNS):
        sign_path = os.path.join(DATA_PATH, sign)
        if not os.path.exists(sign_path):
            print(f"Warning: Data directory for sign '{sign}' not found. Skipping.")
            continue

        for sequence_file in os.listdir(sign_path):
            if sequence_file.endswith('.npy'):
                file_path = os.path.join(sign_path, sequence_file)
                try:
                    data = np.load(file_path)
                    if data.shape == (SEQUENCE_LENGTH, NUM_FEATURES):
                        sequences.append(data)
                        labels.append(label_map[sign])
                    else:
                        print(f"Warning: Skipping {file_path} due to incorrect shape: {data.shape}")
                except Exception as e:
                    print(f"Error loading {file_path}: {e}")

    X = np.array(sequences)
    y = to_categorical(np.array(labels)).astype(int) # One-hot encode labels

    print(f"Loaded {len(sequences)} sequences with shape {X.shape}")
    print(f"Labels shape: {y.shape}")
    return X, y

# --- Build and Train Model ---
def build_and_train_model(X, y):
    """
    Builds, compiles, and trains an LSTM model.
    """
    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    print(f"Training data shape: {X_train.shape}")
    print(f"Testing data shape: {X_test.shape}")

    # Define the LSTM model architecture
    model = Sequential([
        LSTM(64, return_sequences=True, activation='relu', input_shape=(SEQUENCE_LENGTH, NUM_FEATURES)),
        Dropout(0.2), # Add dropout for regularization
        LSTM(128, return_sequences=True, activation='relu'),
        Dropout(0.2),
        LSTM(64, return_sequences=False, activation='relu'),
        Dropout(0.2),
        Dense(64, activation='relu'),
        Dense(32, activation='relu'),
        Dense(len(SIGNS), activation='softmax') # Output layer with softmax for multi-class classification
    ])

    # Compile the model
    model.compile(optimizer='Adam', loss='categorical_crossentropy', metrics=['accuracy'])

    # Define callbacks for training
    # TensorBoard for visualization
    log_dir = os.path.join('Logs')
    tb_callback = TensorBoard(log_dir=log_dir)

    # Early stopping to prevent overfitting
    early_stopping = EarlyStopping(monitor='val_loss', patience=15, restore_best_weights=True)

    # Reduce learning rate on plateau
    reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.2, patience=5, min_lr=0.00001)

    # Train the model
    print("Training model...")
    history = model.fit(
        X_train, y_train,
        epochs=100, # You might need more or fewer epochs depending on data size
        batch_size=32,
        validation_data=(X_test, y_test),
        callbacks=[tb_callback, early_stopping, reduce_lr]
    )

    # Evaluate the model on the test set
    loss, accuracy = model.evaluate(X_test, y_test, verbose=0)
    print(f"\nModel Evaluation:")
    print(f"  Test Loss: {loss:.4f}")
    print(f"  Test Accuracy: {accuracy:.4f}")

    # Plot training history
    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1)
    plt.plot(history.history['accuracy'], label='Train Accuracy')
    plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
    plt.title('Model Accuracy')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend()

    plt.subplot(1, 2, 2)
    plt.plot(history.history['loss'], label='Train Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.title('Model Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.tight_layout()
    plt.show()

    # Save the trained model
    model_filename = os.path.join(MODELS_PATH, 'sign_language_model.h5')
    model.save(model_filename)
    print(f"Model saved to: {model_filename}")

    return model

if __name__ == "__main__":
    X, y = load_data()
    if X.size > 0: # Check if any data was loaded
        model = build_and_train_model(X, y)
    else:
        print("No data loaded. Please run 'collect_data.py' first to gather data.")

