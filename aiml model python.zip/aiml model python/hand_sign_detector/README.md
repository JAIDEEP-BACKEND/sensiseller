# Hand Sign Detector

This project is designed to recognize hand signs using machine learning techniques. It includes functionalities for collecting data, training a model, and real-time detection of hand signs.

## Project Structure

```
hand_sign_detector/
├── collect_data.py        # Script to collect data for hand signs
├── train_model.py         # Script to train the machine learning model
├── realtime_detector.py    # Script for real-time hand sign detection
├── signs.txt              # Text file listing the signs to recognize
├── data/                  # Directory for storing collected landmark data
│   ├── hi/                # Data for the sign "hi"
│   ├── go/                # Data for the sign "go"
│   └── ...                # Additional signs
├── models/                # Directory for storing the trained model
│   └── sign_language_model.h5  # Trained model file
└── README.md              # Project documentation
```

## Setup Instructions

1. Clone the repository:
   ```
   git clone <repository-url>
   cd hand_sign_detector
   ```

2. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

## Usage Guidelines

- **Collecting Data**: Run `collect_data.py` to capture video frames and collect landmark data for the desired hand signs. Make sure to define the signs in `signs.txt`.

- **Training the Model**: After collecting data, use `train_model.py` to train the model. This script will load the data from the `data/` directory and save the trained model in the `models/` directory.

- **Real-time Detection**: Use `realtime_detector.py` to start the real-time detection of hand signs. The script will utilize the trained model to recognize signs from video input.

## Additional Information

- Ensure that your environment has access to a camera for real-time detection.
- Modify the `signs.txt` file to include any additional signs you wish to recognize.
- The collected data will be stored in the `data/` directory, organized by sign name.

For any issues or contributions, please open an issue or pull request in the repository.