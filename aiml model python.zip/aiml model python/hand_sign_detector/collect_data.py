import cv2
import mediapipe as mp
import numpy as np
import os
import time

# --- Configuration ---
# Path to the directory where collected data will be stored
DATA_PATH = os.path.join('data')

# A list of signs you want to collect data for.
# You can also load these from a file (e.g., 'signs.txt')
# For this example, let's define them here or load from 'signs.txt'
# Example: SIGNS = ['hi', 'go', 'hello', 'thank_you']
# If you have a signs.txt file, uncomment and use the following:
try:
    with open('hand_sign_detector/signs.txt', 'r') as f:
        SIGNS = [line.strip() for line in f if line.strip()]
except FileNotFoundError:
    print("Warning: 'signs.txt' not found. Using default signs: ['hi', 'go'].")
    print("Please create a 'signs.txt' file with each sign on a new line, or modify the SIGNS list in the script.")
    SIGNS = ['hi', 'go'] # Default signs if file not found

# Number of sequences (videos/examples) to collect for each sign
NUM_SEQUENCES = 8

# Number of frames (timesteps) in each sequence
SEQUENCE_LENGTH = 30

# --- MediaPipe Setup ---
mp_hands = mp.solutions.hands
# Initialize MediaPipe Hands model with detection and tracking confidence
hands = mp_hands.Hands(min_detection_confidence=0.7, min_tracking_confidence=0.7)
mp_drawing = mp.solutions.drawing_utils # Utility for drawing landmarks

# --- Create Data Directories ---
# Create parent data directory if it doesn't exist
if not os.path.exists(DATA_PATH):
    os.makedirs(DATA_PATH)

# Create subdirectories for each sign if they don't exist
for sign in SIGNS:
    sign_path = os.path.join(DATA_PATH, sign)
    if not os.path.exists(sign_path):
        os.makedirs(sign_path)

# --- Helper Function to Extract Landmarks ---
def extract_landmarks(results):
    """
    Extracts hand landmark coordinates from MediaPipe results.
    Returns a flattened numpy array of (x, y, z) coordinates for all 21 landmarks.
    If no hand is detected, returns a zero array of the same shape.
    """
    if results.multi_hand_landmarks:
        # Assuming only one hand for simplicity. If multiple hands, you might
        # need logic to select the dominant hand or process both.
        hand_landmarks = results.multi_hand_landmarks[0]
        # Flatten the 21 landmarks (x, y, z) into a 1D array (21 * 3 = 63 values)
        keypoints = np.array([[lmk.x, lmk.y, lmk.z] for lmk in hand_landmarks.landmark]).flatten()
    else:
        # Return an array of zeros if no hand is detected, maintaining consistent input shape
        keypoints = np.zeros(21 * 3) # 21 landmarks * 3 coordinates (x,y,z)
    return keypoints

# --- Main Data Collection Loop ---
def collect_data():
    cap = cv2.VideoCapture(0) # Open default webcam

    if not cap.isOpened():
        print("Error: Could not open webcam.")
        return

    print(f"Starting data collection for {len(SIGNS)} signs.")
    print(f"Each sign will have {NUM_SEQUENCES} sequences, each {SEQUENCE_LENGTH} frames long.")
    print("Press 'q' to quit at any time.")

    for sign_idx, sign in enumerate(SIGNS):
        print(f"\n--- Collecting data for: '{sign}' ({sign_idx + 1}/{len(SIGNS)}) ---")

        for sequence_idx in range(NUM_SEQUENCES):
            # Array to store landmarks for the current sequence
            sequence_data = []
            frame_count = 0

            # Display countdown before starting to record the sequence
            for i in range(3, 0, -1):
                ret, frame = cap.read()
                if not ret: break
                frame = cv2.flip(frame, 1) # Flip frame horizontally
                cv2.putText(frame, f'GET READY FOR: {sign.upper()}', (50, 50),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2, cv2.LINE_AA)
                cv2.putText(frame, f'STARTING IN {i}...', (50, 100),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2, cv2.LINE_AA)
                cv2.imshow('Data Collection', frame)
                cv2.waitKey(500) # Wait 0.5 seconds
                if cv2.waitKey(1) & 0xFF == ord('q'): # Allow quitting during countdown
                    cap.release()
                    cv2.destroyAllWindows()
                    return

            print(f"  Recording sequence {sequence_idx + 1}/{NUM_SEQUENCES} for '{sign}'...")

            while frame_count < SEQUENCE_LENGTH:
                ret, frame = cap.read()
                if not ret: break

                frame = cv2.flip(frame, 1) # Flip frame horizontally for mirror effect

                # Convert the BGR image to RGB (MediaPipe requires RGB)
                image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                image_rgb.flags.writeable = False # Optimize: make image non-writeable

                # Process the image with MediaPipe Hands
                results = hands.process(image_rgb)

                image_rgb.flags.writeable = True # Make image writeable again
                image_bgr = cv2.cvtColor(image_rgb, cv2.COLOR_RGB2BGR) # Convert back to BGR for OpenCV display

                # Draw hand landmarks on the frame
                if results.multi_hand_landmarks:
                    for hand_landmarks in results.multi_hand_landmarks:
                        mp_drawing.draw_landmarks(image_bgr, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                # Extract landmarks and add to sequence data
                keypoints = extract_landmarks(results)
                sequence_data.append(keypoints)
                frame_count += 1

                # Display progress
                cv2.putText(image_bgr, f'SIGN: {sign.upper()}', (50, 50),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)
                cv2.putText(image_bgr, f'SEQ: {sequence_idx + 1}/{NUM_SEQUENCES}', (50, 100),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)
                cv2.putText(image_bgr, f'FRAME: {frame_count}/{SEQUENCE_LENGTH}', (50, 150),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2, cv2.LINE_AA)

                cv2.imshow('Data Collection', image_bgr)

                if cv2.waitKey(1) & 0xFF == ord('q'):
                    cap.release()
                    cv2.destroyAllWindows()
                    return

            # Save the collected sequence data
            sequence_filename = os.path.join(DATA_PATH, sign, f'{sequence_idx}.npy')
            np.save(sequence_filename, np.array(sequence_data))
            print(f"    Saved sequence to: {sequence_filename}")

    print("\nData collection complete!")
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    collect_data()
